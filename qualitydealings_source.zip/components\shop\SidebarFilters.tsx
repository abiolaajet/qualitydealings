'use client';

import React from 'react';
import { useRouter, useSearchParams } from 'next/navigation';

const SidebarFilters = () => {
  const router = useRouter();
  const searchParams = useSearchParams();

  const currentBrand = searchParams.get('brand') || '';
  const currentCategory = searchParams.get('category') || '';
  const currentPriceSort = searchParams.get('sort') || '';

  const updateFilter = (key: string, value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (value) {
      params.set(key, value);
    } else {
      params.delete(key);
    }
    router.push(`/shop?${params.toString()}`);
  };

  return (
    <aside className="w-full lg:w-64 flex-shrink-0 space-y-8">
      {/* Category Filter */}
      <div>
        <h4 className="font-black text-sm uppercase tracking-wider mb-4 border-b pb-2">Category</h4>
        <div className="space-y-2">
          {['Electronics', 'Computers', 'Phones', 'Appliances'].map((cat) => (
            <label key={cat} className="flex items-center gap-3 cursor-pointer group">
              <input 
                type="radio" 
                name="category"
                checked={currentCategory === cat.toLowerCase()}
                onChange={() => updateFilter('category', cat.toLowerCase())}
                className="w-4 h-4 text-[#0046be]"
              />
              <span className="text-sm font-medium text-gray-600 group-hover:text-[#0046be]">{cat}</span>
            </label>
          ))}
          <button 
            onClick={() => updateFilter('category', '')}
            className="text-xs text-[#0046be] font-bold hover:underline pt-2"
          >
            Clear Categories
          </button>
        </div>
      </div>

      {/* Brand Filter */}
      <div>
        <h4 className="font-black text-sm uppercase tracking-wider mb-4 border-b pb-2">Brand</h4>
        <div className="space-y-2">
          {['Apple', 'Samsung', 'Sony', 'Dyson', 'Microsoft'].map((brand) => (
            <label key={brand} className="flex items-center gap-3 cursor-pointer group">
              <input 
                type="checkbox" 
                checked={currentBrand === brand}
                onChange={() => updateFilter('brand', currentBrand === brand ? '' : brand)}
                className="w-4 h-4 rounded border-gray-300 text-[#0046be]"
              />
              <span className="text-sm font-medium text-gray-600 group-hover:text-[#0046be]">{brand}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Price Sort */}
      <div>
        <h4 className="font-black text-sm uppercase tracking-wider mb-4 border-b pb-2">Sort by Price</h4>
        <div className="space-y-2">
          <label className="flex items-center gap-3 cursor-pointer group">
            <input 
              type="radio" 
              name="sort"
              checked={currentPriceSort === 'priceLow'}
              onChange={() => updateFilter('sort', 'priceLow')}
              className="w-4 h-4 text-[#0046be]"
            />
            <span className="text-sm font-medium text-gray-600 group-hover:text-[#0046be]">Price: Low to High</span>
          </label>
          <label className="flex items-center gap-3 cursor-pointer group">
            <input 
              type="radio" 
              name="sort" 
              checked={currentPriceSort === 'priceHigh'}
              onChange={() => updateFilter('sort', 'priceHigh')}
              className="w-4 h-4 text-[#0046be]"
            />
            <span className="text-sm font-medium text-gray-600 group-hover:text-[#0046be]">Price: High to Low</span>
          </label>
        </div>
      </div>

      {/* Customer Ratings */}
      <div>
        <h4 className="font-black text-sm uppercase tracking-wider mb-4 border-b pb-2">Customer Rating</h4>
        <div className="space-y-2 text-xs font-bold text-gray-500">
           {/* Placeholder for ratings filter */}
           4 Stars & Up
        </div>
      </div>
    </aside>
  );
};

export default SidebarFilters;
