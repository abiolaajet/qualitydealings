'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Search, ShoppingCart, User, Menu, MapPin, Heart, LogOut, ChevronDown } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { useAuth } from '@/context/AuthContext';

const Header = () => {
  const { cartCount } = useCart();
  const { user, logout } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  return (
    <header className="glass-header">
      {/* Top Strip */}
      <div className="bg-[#003399] py-1 text-[11px] font-medium border-b border-white/10">
        <div className="container-custom flex justify-between items-center">
          <div className="flex gap-4">
            <Link href="/shop" className="hover:opacity-80">Shop</Link>
            <Link href="/brands" className="hover:opacity-80">Brands</Link>
            <Link href="/deals" className="hover:opacity-80">Deals</Link>
            <Link href="/services" className="hover:opacity-80">Services</Link>
          </div>
          <div className="flex gap-4">
            <Link href="/order-status" className="hover:opacity-80">Order Status</Link>
            <Link href="/help" className="hover:opacity-80">Help Centre</Link>
            <span className="flex items-center gap-1"><MapPin size={10} /> Find a Store</span>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="py-4">
        <div className="container-custom flex items-center gap-8">
          {/* Logo */}
          <Link href="/" className="flex-shrink-0">
            <h1 className="text-2xl font-bold tracking-tighter">
              Quality<span className="text-[var(--accent)]">Dealings</span>
            </h1>
          </Link>

          {/* Menu Button */}
          <button className="flex items-center gap-2 font-semibold hover:opacity-80 text-sm">
            <Menu size={20} />
            <span>Menu</span>
          </button>

          {/* Search Bar */}
          <div className="flex-grow max-w-2xl relative group">
            <div className="flex items-center bg-white rounded-md overflow-hidden shadow-sm focus-within:ring-2 focus-within:ring-[var(--accent)]">
              <input 
                type="text" 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search QualityDealings..." 
                className="w-full px-4 py-2.5 text-black outline-none text-sm"
              />
              <button className="bg-white p-2.5 text-[#0046be] hover:bg-gray-100 transition-colors">
                <Search size={20} />
              </button>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-6">
            {/* User Account */}
            <div className="relative group">
              {user ? (
                <div 
                  className="flex items-center gap-2 cursor-pointer hover:opacity-80"
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                >
                  <div className="w-8 h-8 bg-[var(--accent)] text-[#0046be] rounded-full flex items-center justify-center font-black text-xs">
                    {user.name[0]}
                  </div>
                  <div className="hidden lg:flex flex-col text-[10px] leading-tight font-normal">
                    <span className="opacity-80">Hi, {user.name.split(' ')[0]}</span>
                    <span className="font-bold text-xs flex items-center gap-0.5">My Account <ChevronDown size={10} /></span>
                  </div>
                </div>
              ) : (
                <Link href="/login" className="flex items-center gap-2 hover:opacity-80">
                  <User size={22} strokeWidth={2.5} />
                  <div className="hidden lg:flex flex-col text-[10px] leading-tight font-normal">
                    <span className="opacity-80">Account</span>
                    <span className="font-bold text-xs">Sign In</span>
                  </div>
                </Link>
              )}

              {/* Dropdown menu if logged in */}
              {user && isUserMenuOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-xl border overflow-hidden z-[100]">
                   <Link href="/profile" className="block px-4 py-2 text-xs text-gray-700 hover:bg-gray-100 font-bold">Profile</Link>
                   <Link href="/orders" className="block px-4 py-2 text-xs text-gray-700 hover:bg-gray-100 font-bold">Orders</Link>
                   {user.role === 'admin' && (
                     <Link href="/admin" className="block px-4 py-2 text-xs text-red-600 hover:bg-gray-100 font-bold border-t">Admin Panel</Link>
                   )}
                   <button 
                     onClick={logout}
                     className="w-full text-left px-4 py-2 text-xs text-gray-700 hover:bg-gray-100 font-bold flex items-center gap-2 border-t"
                   >
                     <LogOut size={14} /> Logout
                   </button>
                </div>
              )}
            </div>

            <Link href="/wishlist" className="hover:opacity-80 relative group flex items-center gap-2">
              <Heart size={22} strokeWidth={2.5} className="group-hover:fill-current" />
              <span className="hidden lg:inline text-sm font-semibold">Wishlist</span>
            </Link>

            <Link href="/cart" className="flex items-center gap-2 hover:opacity-80 relative">
              <div className="relative">
                <ShoppingCart size={22} strokeWidth={2.5} />
                {cartCount > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 bg-[var(--accent)] text-[#0046be] text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center animate-bounce">
                    {cartCount}
                  </span>
                )}
              </div>
              <span className="hidden lg:inline text-sm font-semibold">Cart</span>
            </Link>
          </div>
        </div>
      </div>

      {/* Tertiary Nav */}
      <nav className="bg-[#003399]/50 py-2 hidden md:block border-t border-white/5">
        <div className="container-custom">
          <ul className="flex gap-8 text-[13px] font-semibold overflow-x-auto whitespace-nowrap scrollbar-hide">
            <Link href="/shop" className="hover:underline underline-offset-4 cursor-pointer">Electronics</Link>
            <Link href="/shop" className="hover:underline underline-offset-4 cursor-pointer">Computers & Tablets</Link>
            <Link href="/shop" className="hover:underline underline-offset-4 cursor-pointer">Appliances</Link>
            <Link href="/shop" className="hover:underline underline-offset-4 cursor-pointer">TV & Home Theatre</Link>
            <Link href="/shop" className="hover:underline underline-offset-4 cursor-pointer">Video Games</Link>
            <Link href="/shop" className="hover:underline underline-offset-4 cursor-pointer">Cell Phones</Link>
            <Link href="/shop" className="hover:underline underline-offset-4 cursor-pointer">Smart Home</Link>
            <Link href="/shop" className="text-[var(--accent)] hover:underline underline-offset-4 cursor-pointer">Clearance</Link>
          </ul>
        </div>
      </nav>
    </header>
  );
};

export default Header;
