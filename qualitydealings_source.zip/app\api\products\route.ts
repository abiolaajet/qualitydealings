import { NextResponse } from 'next/server';
import dbConnect from '@/lib/db';
import Product from '@/models/Product';

export async function GET(request: Request) {
  await dbConnect();

  const { searchParams } = new URL(request.url);
  
  const category = searchParams.get('category');
  const brand = searchParams.get('brand');
  const minPrice = searchParams.get('minPrice');
  const maxPrice = searchParams.get('maxPrice');
  const sort = searchParams.get('sort') || 'createdAt';
  const page = parseInt(searchParams.get('page') || '1');
  const limit = 12;

  const query: Record<string, any> = {};

  if (category) query.category = category;
  if (brand) query.brand = brand;
  if (minPrice || maxPrice) {
    query.price = {};
    if (minPrice) query.price.$gte = Number(minPrice);
    if (maxPrice) query.price.$lte = Number(maxPrice);
  }

  try {
    const total = await Product.countDocuments(query);
    const products = await Product.find(query)
      .sort(sort === 'priceLow' ? 'price' : sort === 'priceHigh' ? '-price' : '-createdAt')
      .skip((page - 1) * limit)
      .limit(limit);

    return NextResponse.json({
      products,
      page,
      pages: Math.ceil(total / limit),
      total
    });
  } catch (error: any) {
    return NextResponse.json({ message: error.message }, { status: 500 });
  }
}
