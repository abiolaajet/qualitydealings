'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { Category } from '@/types';

const CategoryGrid = () => {
  const [categories, setCategories] = useState<Category[]>([]);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const res = await fetch('/api/categories');
        const data = await res.json();
        setCategories(data);
      } catch (err) {
        console.error('Error fetching categories:', err);
      }
    };
    fetchCategories();
  }, []);

  return (
    <section className="bg-white py-12">
      <div className="container-custom">
        <h2 className="text-xl font-black text-[#1d1d1f] mb-8 tracking-tight">Shop by Category</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories.map((cat) => (
            <Link 
              key={cat._id} 
              href={`/category/${cat.slug}`}
              className="group flex flex-col items-center p-6 bg-gray-50 rounded-lg hover:bg-white hover:shadow-lg transition-all border border-transparent hover:border-gray-100"
            >
              <div className="w-20 h-20 relative mb-4 flex items-center justify-center bg-white rounded-full p-4 group-hover:scale-110 transition-transform">
                {/* Fallback icon or image */}
                <div className="text-[#0046be] font-bold text-lg">{cat.name[0]}</div>
              </div>
              <span className="text-sm font-bold text-center text-[#1d1d1f] group-hover:text-[#0046be]">
                {cat.name}
              </span>
            </Link>
          ))}
          
          {/* Static placeholders if empty */}
          {categories.length === 0 && (
             <div className="flex gap-4">
               {[...Array(6)].map((_, i) => (
                 <div key={i} className="w-32 h-32 skeleton"></div>
               ))}
             </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default CategoryGrid;
