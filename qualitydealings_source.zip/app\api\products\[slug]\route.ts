import { NextResponse } from 'next/server';
import dbConnect from '@/lib/db';
import Product from '@/models/Product';
import Category from '@/models/Category';

export async function GET(
  request: Request,
  { params }: { params: Promise<{ slug: string }> }
) {
  await dbConnect();
  const resolvedParams = await params;

  try {
    const product = await Product.findOne({ slug: resolvedParams.slug }).populate('category');
    
    if (!product) {
      return NextResponse.json({ message: 'Product not found' }, { status: 404 });
    }

    // Fetch related products (same category)
    const related = await Product.find({
      category: product.category._id,
      _id: { $ne: product._id }
    }).limit(4);

    return NextResponse.json({ product, related });
  } catch (error: any) {
    return NextResponse.json({ message: error.message }, { status: 500 });
  }
}
