'use client';

import React, { useState, useEffect } from 'react';
import AdminSidebar from '@/components/admin/AdminSidebar';
import { useRouter } from 'next/navigation';
import { Save, X, ImageIcon } from 'lucide-react';
import Link from 'next/link';
import { Category as CategoryType } from '@/types';

export default function NewProductPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [categories, setCategories] = useState<CategoryType[]>([]);
  
  const [formData, setFormData] = useState({
    name: '',
    slug: '',
    description: '',
    price: '',
    stock: '',
    brand: '',
    category: '',
    imageUrl: '',
    isFeatured: false,
  });

  useEffect(() => {
    // Fetch categories for dropdown
    const fetchCats = async () => {
      const res = await fetch('/api/categories');
      const data = await res.json();
      setCategories(data);
    };
    fetchCats();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await fetch('/api/products/new', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          price: Number(formData.price),
          stock: Number(formData.stock),
          images: [formData.imageUrl || 'https://images.unsplash.com/photo-1526733170373-be78f0f2e8f1?auto=format&fit=crop&q=80&w=800'],
        }),
      });

      if (res.ok) {
        router.push('/admin/products');
      } else {
        const data = await res.json();
        alert(data.message || 'Error occurred');
      }
    } catch (err) {
      console.error(err);
      alert('Failed to create product');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex bg-gray-50 min-h-screen">
      <AdminSidebar />
      <main className="flex-grow p-10">
        <div className="flex justify-between items-center mb-10">
           <div>
              <h1 className="text-3xl font-black text-gray-900 tracking-tighter">New Product</h1>
              <p className="text-sm text-gray-500 font-medium">Add a new item to your storefront catalog.</p>
           </div>
           <Link 
             href="/admin/products" 
             className="bg-white border text-gray-600 px-6 py-3 rounded-lg font-black text-sm flex items-center gap-2 hover:bg-gray-50 transition-all shadow-sm"
           >
             <X size={18} /> Cancel
           </Link>
        </div>

        <form onSubmit={handleSubmit} className="bg-white p-10 rounded-2xl shadow-xl border border-gray-100 max-w-4xl">
           <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Basic Info */}
              <div className="space-y-6">
                 <div>
                    <label className="block text-xs font-black uppercase tracking-widest text-gray-400 mb-2">Product Name</label>
                    <input 
                      type="text" 
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value, slug: e.target.value.toLowerCase().replace(/ /g, '-')})}
                      placeholder="e.g. Sony WH-1000XM5 Headphones"
                      className="w-full px-4 py-3 bg-gray-50 border-gray-100 rounded-lg text-sm focus:bg-white focus:ring-2 focus:ring-[#0046be] outline-none transition-all"
                    />
                 </div>
                 <div>
                    <label className="block text-xs font-black uppercase tracking-widest text-gray-400 mb-2">Slug (URL)</label>
                    <input 
                      type="text" 
                      required
                      value={formData.slug}
                      onChange={(e) => setFormData({...formData, slug: e.target.value})}
                      className="w-full px-4 py-3 bg-gray-50 border-gray-100 rounded-lg text-sm text-gray-400 font-mono focus:bg-white focus:ring-2 focus:ring-[#0046be] outline-none"
                    />
                 </div>
                 <div>
                    <label className="block text-xs font-black uppercase tracking-widest text-gray-400 mb-2">Brand</label>
                    <input 
                      type="text" 
                      required
                      value={formData.brand}
                      onChange={(e) => setFormData({...formData, brand: e.target.value})}
                      placeholder="e.g. Sony"
                      className="w-full px-4 py-3 bg-gray-50 border-gray-100 rounded-lg text-sm focus:bg-white focus:ring-2 focus:ring-[#0046be] outline-none"
                    />
                 </div>
                 <div>
                    <label className="block text-xs font-black uppercase tracking-widest text-gray-400 mb-2">Description</label>
                    <textarea 
                      required
                      rows={5}
                      value={formData.description}
                      onChange={(e) => setFormData({...formData, description: e.target.value})}
                      placeholder="Tell customers about this product..."
                      className="w-full px-4 py-3 bg-gray-50 border-gray-100 rounded-lg text-sm focus:bg-white focus:ring-2 focus:ring-[#0046be] outline-none"
                    />
                 </div>
              </div>

              {/* Inventory & Media */}
              <div className="space-y-6">
                 <div className="grid grid-cols-2 gap-4">
                    <div>
                       <label className="block text-xs font-black uppercase tracking-widest text-gray-400 mb-2">Price (£)</label>
                       <input 
                         type="number" 
                         required
                         value={formData.price}
                         onChange={(e) => setFormData({...formData, price: e.target.value})}
                         className="w-full px-4 py-3 bg-gray-50 border-gray-100 rounded-lg text-sm focus:bg-white focus:ring-2 focus:ring-[#0046be] outline-none"
                       />
                    </div>
                    <div>
                       <label className="block text-xs font-black uppercase tracking-widest text-gray-400 mb-2">Stock</label>
                       <input 
                         type="number" 
                         required
                         value={formData.stock}
                         onChange={(e) => setFormData({...formData, stock: e.target.value})}
                         className="w-full px-4 py-3 bg-gray-50 border-gray-100 rounded-lg text-sm focus:bg-white focus:ring-2 focus:ring-[#0046be] outline-none"
                       />
                    </div>
                 </div>

                 <div>
                    <label className="block text-xs font-black uppercase tracking-widest text-gray-400 mb-2">Category</label>
                    <select 
                      required
                      value={formData.category}
                      onChange={(e) => setFormData({...formData, category: e.target.value})}
                      className="w-full px-4 py-3 bg-gray-50 border-gray-100 rounded-lg text-sm focus:bg-white focus:ring-2 focus:ring-[#0046be] outline-none font-bold"
                    >
                       <option value="">Select Category</option>
                       {categories.map(c => <option key={c._id} value={c._id}>{c.name}</option>)}
                    </select>
                 </div>

                 <div>
                    <label className="block text-xs font-black uppercase tracking-widest text-gray-400 mb-2">Main Image URL</label>
                    <div className="relative">
                       <ImageIcon className="absolute left-3 top-3 text-gray-400" size={18} />
                       <input 
                         type="text" 
                         required
                         value={formData.imageUrl}
                         onChange={(e) => setFormData({...formData, imageUrl: e.target.value})}
                         placeholder="https://..."
                         className="w-full pl-10 pr-4 py-3 bg-gray-50 border-gray-100 rounded-lg text-sm focus:bg-white focus:ring-2 focus:ring-[#0046be] outline-none"
                       />
                    </div>
                 </div>

                 <div className="flex items-center gap-3 pt-4">
                    <input 
                      type="checkbox" 
                      id="isFeatured"
                      checked={formData.isFeatured}
                      onChange={(e) => setFormData({...formData, isFeatured: e.target.checked})}
                      className="w-5 h-5 text-[#0046be] rounded border-gray-300" 
                    />
                    <label htmlFor="isFeatured" className="text-sm font-bold text-gray-700">Display in Featured Section on Home</label>
                 </div>
              </div>
           </div>

           <div className="mt-12 flex justify-end">
              <button 
                type="submit"
                disabled={loading}
                className="bg-[#0046be] text-white px-10 py-4 rounded-xl font-black text-lg hover:bg-[#003399] transition-all shadow-xl flex items-center gap-3 disabled:opacity-50"
              >
                <Save size={20} />
                {loading ? 'Creating...' : 'Create Product'}
              </button>
           </div>
        </form>
      </main>
    </div>
  );
}
